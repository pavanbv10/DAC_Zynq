/*
 * Copyright (C) 2009 - 2019 Xilinx, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 */

#include <stdio.h>
#include <string.h>

#include "xaxidma.h"
#include "xgpio.h"
#include "xparameters.h"
#include "xstatus.h"
#include "sleep.h"
#include "xil_cache.h"
#include "netif/xadapter.h"

#include "lwip/err.h"
#include "lwip/tcp.h"
#if defined (__arm__) || defined (__aarch64__)
#include "xil_printf.h"
#endif

// my variables (sukho)
struct tcp_pcb *my_tcb;
int flag_debug = 0; // change this to 1 for debugging (print status on the console)
int flag_send_data_eth = 0;
int iloop = 0;
char carry_str [20];
char last_prev_char [2];
u32 data[400000] = { 0 };
u32 data_len = 0;
u32 data_cnt = 0;
u32 iDataStart = 0;

int transfer_data(struct tcp_pcb *tpcb, err_t err) {
	/***********************/
	/* after sending the data to the PL, now we echo back the (large) data through the ethernet*/
	/***********************/
	int SendBuffer;
	int send_data_len = 1000;
	char tmp[10000] = { 0 };
	int tmp_data_len;
	int index = 0;
	int tmp_str_len;

	if (flag_send_data_eth) {
		if ( iDataStart == 0 ) print("\rStart sending data back through the ethernet..\n\r");

		if ( (data_len - iDataStart) >= send_data_len) tmp_data_len = send_data_len;
		else tmp_data_len = data_len - iDataStart;

		//see https://stackoverflow.com/questions/30234363/how-can-i-convert-an-int-array-into-a-string-array
		for (int ii = iDataStart; ii < (iDataStart + tmp_data_len); ii++) {
		   index += sprintf(&tmp[index], "%lu,", data[ii]);
		}
		if ( (data_len - iDataStart) <= send_data_len) sprintf(&tmp[index-1], ";");
		tmp_str_len = strlen(tmp);

		// get available sendbuffer size
		SendBuffer = tcp_sndbuf(tpcb);

		// debug: print each data set
		if (flag_debug) {
			printf("SendBuffer: %d, tmp_str_len: %d, tmp str: ", SendBuffer, tmp_str_len);
			if ( tmp_str_len < 1000 ) printf("%s", tmp);
			else {
				for (int ii = 0; ii < 10; ii++)	printf("%c", tmp[ii]);
				printf("...");
				for (int ii = tmp_str_len - 10; ii < tmp_str_len; ii++)	printf("%c", tmp[ii]);
			}
			printf("\n\r");
		}

		// write data
		tmp_str_len = strlen(tmp);
		if ( SendBuffer > tmp_str_len ) {
			err = tcp_write(tpcb, tmp, tmp_str_len, 1);

			// move to the next values in the data package
			iDataStart = iDataStart + tmp_data_len;
		}

		// done sending data, reset parameters
		if (iDataStart >= data_len) {
			printf("\rDone...\n\r");
			flag_send_data_eth = 0;
			iDataStart = 0;
		}
	}

	return 0;
}

void print_app_header()
{
#if (LWIP_IPV6==0)
	xil_printf("\n\r\n\r-----lwIP TCP echo server ------\n\r");
#else
	xil_printf("\n\r\n\r-----lwIPv6 TCP echo server ------\n\r");
#endif
	xil_printf("TCP packets sent to port 6001 will be echoed back\n\r");
}

err_t recv_callback(void *arg, struct tcp_pcb *tpcb,
                               struct pbuf *p, err_t err)
{
	/* do not read the packet if we are not in ESTABLISHED state */
	if (!p) {
		tcp_close(tpcb);
		tcp_recv(tpcb, NULL);
		return ERR_OK;
	}
	if (my_tcb != tpcb) my_tcb = tpcb; // add global pcb for the main function (sukho)

	/* indicate that the packet has been received */
	tcp_recved(tpcb, p->len);

	/***********************/
	/* This is my function */
	/***********************/

	// declare variables
	char var_input[1500] = { 0 };
	char first_curr_char [2];
	char last_curr_char [2];
	char *token;
	int flag_appen_prev = 0;

	// append data string
	memcpy(var_input, p->payload, p->len); // copy payload to var_input
	strncpy(first_curr_char, var_input, 1);
	strncpy(last_curr_char, var_input + p->len - 1, 1); // last char of previous set

	if ( !((strncmp(first_curr_char, ",", 1) == 0) || (strncmp(last_prev_char, ",", 1) == 0)) ) {
		if (iloop != 0) flag_appen_prev = 1; // avoid append for the first loop
	}

	// collect data each round, taking into account the partial data string of the previous set
	token = strtok(var_input, ","); // first token
	if (flag_appen_prev) {
		data_cnt--;
		strcat(carry_str, token);
		data[data_cnt] = atof(carry_str);
	} else data[data_cnt] = atof(token);

	if( token == NULL) {
		puts("  No separators found");
		return -1;
	}
	while(token != NULL) {
		strcpy(carry_str, token);
		token = strtok(NULL, ",");
		data_cnt++;
		data[data_cnt] = atof(token);
	}

	// end of loop
	strcpy(last_prev_char, last_curr_char); // last char of previous loop
	iloop++;

	// if end of data package
	if ( (var_input[p->len - 3] == ';') || (p->len < 3) ) { // end of data package

		printf("\n...end of data package...\n\r.........................\n\r");

		// print data from array
		data_len = data_cnt;
		printf("data values: ");
		if (data_len < 1000) {
			for (int ii = 0; ii < data_len; ii++) {
				printf("%lu ", data[ii]);
			}
		}
		else {
			for (int ii = 0; ii < 3; ii++) {
				printf("%lu ", data[ii]);
			}
			printf("... ");
			for (int ii = data_len - 3; ii < data_len; ii++) {
				printf("%lu ", data[ii]);
			}
		}
		printf("\ndata len: %lu\n", data_len);

		// reset data
		data_cnt = 0;
		iloop = 0;

		/***********************/
		/* now we have array of (u32)data */
		/* next is to stream the data to through the DMA */
		/* based on the hardware design */
		/* follow this https://www.youtube.com/watch?v=x3KyWuhGmJg */
		/***********************/
		u32 status, RS;
		int gpio_id;
		int gpio_ch;
		XGpio gpio;

		XAxiDma_Config *myDmaConfig;
		XAxiDma myDma;

		// set address to zero
		gpio_id = XPAR_AXI_GPIO_0_DEVICE_ID;
		gpio_ch = 1;
		XGpio_Initialize(&gpio, gpio_id);
		XGpio_SetDataDirection(&gpio, gpio_ch, 0); // output only
		XGpio_DiscreteWrite(&gpio, gpio_ch, 0);

		myDmaConfig = XAxiDma_LookupConfigBaseAddr(XPAR_AXI_DMA_0_BASEADDR);
		status = XAxiDma_CfgInitialize(&myDma, myDmaConfig);
		if ( status != XST_SUCCESS ) {
			printf("DMA initialization failed\n");
			return -1;
		}
		printf("DMA initialization success..\n");

		RS = Xil_In32((u32)(XPAR_AXI_DMA_0_BASEADDR)) & XAXIDMA_HALTED_MASK; // checkHalted
		status = Xil_In32((u32)(XPAR_AXI_DMA_0_BASEADDR + 0x4)) & XAXIDMA_HALTED_MASK; // checkHalted
		if (flag_debug) xil_printf("Status before data transfer %0x, RS: %0x\n", status, RS);
		Xil_DCacheFlushRange( (u32)data, data_len*sizeof(u32) );

		status = XAxiDma_SimpleTransfer(&myDma, (u32)data, data_len*sizeof(u32), XAXIDMA_DMA_TO_DEVICE);
		Xil_Out32((u32)(XPAR_AXI_DMA_0_BASEADDR), 0); // I have to force run/stop, otherwise the haled status won't update. Need to check my hardware design
		if ( status != XST_SUCCESS ) {
			print("DMA initialization failed\n");
			return -1;
		}

		RS = Xil_In32((u32)(XPAR_AXI_DMA_0_BASEADDR)) & XAXIDMA_HALTED_MASK; // checkHalted
		status = Xil_In32((u32)(XPAR_AXI_DMA_0_BASEADDR + 0x4)) & XAXIDMA_HALTED_MASK; // checkHalted
		while ( status != 1 ) {
			if (flag_debug) xil_printf("\rRS: %0x, status: %0x\n", RS, status);
			RS = Xil_In32((u32)(XPAR_AXI_DMA_0_BASEADDR)) & XAXIDMA_HALTED_MASK; // checkHalted
			status = Xil_In32((u32)(XPAR_AXI_DMA_0_BASEADDR + 0x4)) & XAXIDMA_HALTED_MASK; // checkHalted
		}
		print("\rDMA transfer success..\n\r");

		XGpio_DiscreteWrite(&gpio, gpio_ch, data_len);
		print("\rStart DAC output..\n\r");

		// flag send data to client
		flag_send_data_eth = 1;
	};
	/***********************/
	/* end my function */
	/***********************/

	/* free the received pbuf */
	pbuf_free(p);

	return ERR_OK;
}

err_t accept_callback(void *arg, struct tcp_pcb *newpcb, err_t err)
{
	static int connection = 1;

	/* set the receive callback for this connection */
	tcp_recv(newpcb, recv_callback);

	/* just use an integer number indicating the connection id as the
	   callback argument */
	tcp_arg(newpcb, (void*)(UINTPTR)connection);

	/* increment for subsequent accepted connections */
	connection++;

	return ERR_OK;
}


int start_application()
{
	struct tcp_pcb *pcb;
	err_t err;
	unsigned port = 7;

	/* create new TCP PCB structure */
	pcb = tcp_new_ip_type(IPADDR_TYPE_ANY);
	if (!pcb) {
		xil_printf("Error creating PCB. Out of Memory\n\r");
		return -1;
	}

	/* bind to specified @port */
	err = tcp_bind(pcb, IP_ANY_TYPE, port);
	if (err != ERR_OK) {
		xil_printf("Unable to bind to port %d: err = %d\n\r", port, err);
		return -2;
	}

	/* we do not need any arguments to callback functions */
	tcp_arg(pcb, NULL);

	/* listen for connections */
	pcb = tcp_listen(pcb);
	if (!pcb) {
		xil_printf("Out of memory while tcp_listen\n\r");
		return -3;
	}

	/* specify callback to use for incoming connections */
	tcp_accept(pcb, accept_callback);

	xil_printf("TCP echo server started @ port %d\n\r", port);

	return 0;
}
